<?php

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="main.css">
        <!-- font awesome -->
        <script src="https://kit.fontawesome.com/dbed6b6114.js" crossorigin="anonymous"></script>
    </head>
    <body>

        <div class = "products">
            <div class = "container">
                <h1 class = "lg-title">Our Products</h1>
                <p class = "text-light">We really listen what our users want , both qualitative listenint to words they say and quantitative looking at the behaviour they take</p>

                <div class = "product-items">
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic1.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Paper Craft Little Birdie</a>
                            <p class = "product-price">$ 2.08</p>
                            <p class = "product-price">$ 1.56</p>
                        </div>

                        <div class = "off-info">
                            <h2 class = "sm-title">25% off</h2>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic2.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Medium Ceramic Top Storage Jar</a>
                            <p class = "product-price">$ 1.04</p>
                            <p class = "product-price">$ 0.78</p>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic3.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">World War 2 Gliders Asstd. Designs</a>
                            <p class = "product-price">$ 0.21</p>
                            <p class = "product-price">$ 0.16</p>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic4.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Jumbo Bag Red Retro-Spot</a>
                            <p class = "product-price">$ 1.95</p>
                            <p class = "product-price">$ 1.47</p>
                        </div>

                        <div class = "off-info">
                            <h2 class = "sm-title">25% off</h2>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic5.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">White Hanging Heart T-Ligth Holder</a>
                            <p class = "product-price">$ 2.95</p>
                            <p class = "product-price">$ 2.22</p>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic6.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Assorted Colour Bird Ornament</a>
                            <p class = "product-price">$ 1.69</p>
                            <p class = "product-price">$ 1.27</p>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic77.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Pack of 72 Retro-Spot Cake</a>
                            <p class = "product-price">$ 0.55</p>
                            <p class = "product-price">$ 0.41</p>
                        </div>
                    </div>
                    <!-- end of single product -->
                    <!-- single product -->
                    <div class = "product">
                        <div class = "product-content">
                            <div class = "product-img">
                                <img src = "images/pic8.jpg" alt = "product image">
                            </div>
                            <div class = "product-btns">
                                <button type = "button" class = "btn-cart"> Give Feedback
                                    <span><i class = "fas fa-plus"></i></span>
                                </button>

                            </div>
                        </div>

                        <div class = "product-info">
                            <div class = "product-info-top">

                            </div>
                            <a href = "#" class = "product-name">Popcorn Holder</a>
                            <p class = "product-price">$ 0.72</p>
                            <p class = "product-price">$ 0.47</p>
                        </div>

                        <div class = "off-info">
                            <h2 class = "sm-title">35% off</h2>
                        </div>
                    </div>
                    <!-- end of single product -->
                </div>
            </div>
        </div>

        <div class = "product-collection">
            <div class = "container">
                <div class = "product-collection-wrapper">
                    <!-- product col left -->
                    <div class = "product-col-left flex">
                        <div class = "product-col-content">
                            <h2 class = "sm-title">men's shoes </h2>
                            <h2 class = "md-title">men's collection </h2>
                            <p class = "text-light">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae consequatur facilis eligendi quibusdam voluptatibus exercitationem autem voluptatum, beatae architecto odit, quisquam repellat. Deleniti, architecto ab.</p>
                            <button type = "button" class = "btn-dark">Shop now</button>
                        </div>
                    </div>

                    <!-- product col right -->
                    <div class = "product-col-right">
                        <div class = "product-col-r-top flex">
                            <div class = "product-col-content">
                                <h2 class = "sm-title">women's dresses </h2>
                                <h2 class = "md-title">women's collection </h2>
                                <p class = "text-light">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae consequatur facilis eligendi quibusdam voluptatibus exercitationem autem voluptatum, beatae architecto odit, quisquam repellat. Deleniti, architecto ab.</p>
                                <button type = "button" class = "btn-dark">Shop now</button>
                            </div>
                        </div>

                        <div class = "product-col-r-bottom">
                            <!-- left -->
                            <div class = "flex">
                                <div class = "product-col-content">
                                    <h2 class = "sm-title">summer sale </h2>
                                    <h2 class = "md-title">Extra 50% Off </h2>
                                    <p class = "text-light">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae consequatur facilis eligendi quibusdam voluptatibus exercitationem autem voluptatum, beatae architecto odit, quisquam repellat. Deleniti, architecto ab.</p>
                                    <button type = "button" class = "btn-dark">Shop now</button>
                                </div>
                            </div>
                            <!-- right -->
                            <div class = "flex">
                                <div class = "product-col-content">
                                    <h2 class = "sm-title">shoes </h2>
                                    <h2 class = "md-title">best sellers </h2>
                                    <p class = "text-light">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae consequatur facilis eligendi quibusdam voluptatibus exercitationem autem voluptatum, beatae architecto odit, quisquam repellat. Deleniti, architecto ab.</p>
                                    <button type = "button" class = "btn-dark">Shop now</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <button type = "button" class = "btn-logout"><a href="index.php">Logout</a>
            <?php 


session_destroy();



?>
</button>
        </div>

    </body>


</html>
